CMSC5743 Lab 02 Submission

Build (requires g++ with C++17 support):
  g++ -std=c++17 -O3 -Wall -o strassen code/strassen_impl.cpp
  g++ -std=c++17 -O3 -Wall -o winograd code/winograd_impl.cpp

Run:
  ./strassen
  ./winograd

Optional local correctness tests:
  g++ -std=c++17 -O3 -Wall -o lab2_tests code/lab2_tests.cpp
  ./lab2_tests

The implementation uses only the C++ standard library.
