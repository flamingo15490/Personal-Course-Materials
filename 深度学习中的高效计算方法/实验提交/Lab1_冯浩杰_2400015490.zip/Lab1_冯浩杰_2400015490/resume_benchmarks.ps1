param(
    [string]$Compiler = "C:\Program Files (x86)\mingw64\bin\g++.exe",
    [int]$Repeats = 3
)

$ErrorActionPreference = "Stop"
$root = $PSScriptRoot
$source = Join-Path $root "lab1_complete.cpp"
$binary = Join-Path $root "lab1_complete.exe"
$q1Csv = Join-Path $root "q1_baseline_results.csv"
$q3Csv = Join-Path $root "q3_optimization_results.csv"

& $Compiler $source -std=c++17 -O3 -Wall -Wextra -o $binary
if ($LASTEXITCODE -ne 0) { throw "Compilation failed." }

$seen = @{}
if (Test-Path $q1Csv) {
    Get-Content $q1Csv | Select-Object -Skip 1 | ForEach-Object {
        $p = $_ -split ','
        if ($p.Count -ge 4) { $seen[($p[0..3] -join ',')] = $true }
    }
} else {
    "algorithm,I,J,K,repeats,avg_ms,gflops" | Set-Content -Encoding ascii $q1Csv
}

foreach ($i in 256, 512, 1024) {
    foreach ($j in 256, 512, 1024) {
        foreach ($k in 256, 512, 1024) {
            foreach ($algorithm in "ijk", "ikj", "at", "bt") {
                $key = "$algorithm,$i,$j,$k"
                if (-not $seen.ContainsKey($key)) {
                    & $binary --benchmark $algorithm $i $j $k $Repeats | Add-Content -Encoding ascii $q1Csv
                    if ($LASTEXITCODE -ne 0) { throw "Benchmark failed: $key" }
                }
            }
        }
    }
}

"algorithm,I,J,K,repeats,avg_ms,gflops" | Set-Content -Encoding ascii $q3Csv
foreach ($algorithm in "ikj", "bt", "blocked", "blocked-unrolled") {
    & $binary --benchmark $algorithm 1024 1024 1024 $Repeats | Add-Content -Encoding ascii $q3Csv
    if ($LASTEXITCODE -ne 0) { throw "Optimization benchmark failed: $algorithm" }
}

Write-Output "Completed missing baselines with $Repeats repetitions."
