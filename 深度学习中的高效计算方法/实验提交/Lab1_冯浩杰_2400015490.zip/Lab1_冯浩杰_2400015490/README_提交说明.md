# Lab1 提交材料

本文件夹包含 Lab1 的报告、源代码、性能数据和复现实验脚本。

- `Lab1_Report.md`：实验报告。
- `lab1_complete.cpp`：GEMM 与 im2col 的完整 C++17 实现。
- `q1_baseline_results.csv`：Q1 的 108 条基线性能记录。
- `q3_optimization_results.csv`：Q3 的缓存优化性能记录。
- `test_lab1.ps1`：正确性测试脚本。
- `run_benchmarks.ps1` 与 `resume_benchmarks.ps1`：性能测试脚本。

提交前将文件夹名称改为 `Lab1_姓名_学号`，然后压缩为 ZIP 上传。
