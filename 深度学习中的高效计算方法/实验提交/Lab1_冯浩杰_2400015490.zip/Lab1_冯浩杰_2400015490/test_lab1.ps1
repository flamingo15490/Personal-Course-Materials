param(
    [string]$Compiler = "C:\Program Files (x86)\mingw64\bin\g++.exe"
)

$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
$source = Join-Path $PSScriptRoot "lab1_complete.cpp"
$binary = Join-Path $PSScriptRoot "lab1_complete.exe"

& $Compiler $source -std=c++17 -O3 -Wall -Wextra -o $binary
if ($LASTEXITCODE -ne 0) {
    throw "Compilation failed."
}

& $binary --self-test
if ($LASTEXITCODE -ne 0) {
    throw "Self-test failed."
}

Write-Output "Lab1 self-test passed."
