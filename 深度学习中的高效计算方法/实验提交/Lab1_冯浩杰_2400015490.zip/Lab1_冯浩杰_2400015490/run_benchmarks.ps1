param(
    [string]$Compiler = "C:\Program Files (x86)\mingw64\bin\g++.exe"
)

$ErrorActionPreference = "Stop"
$root = $PSScriptRoot
$source = Join-Path $root "lab1_complete.cpp"
$binary = Join-Path $root "lab1_complete.exe"
$q1Csv = Join-Path $root "q1_baseline_results.csv"
$q3Csv = Join-Path $root "q3_optimization_results.csv"

& $Compiler $source -std=c++17 -O3 -Wall -Wextra -o $binary
if ($LASTEXITCODE -ne 0) { throw "Compilation failed." }

"algorithm,I,J,K,repeats,avg_ms,gflops" | Set-Content -Encoding ascii $q1Csv
foreach ($i in 256, 512, 1024) {
    foreach ($j in 256, 512, 1024) {
        foreach ($k in 256, 512, 1024) {
            foreach ($algorithm in "ijk", "ikj", "at", "bt") {
                & $binary --benchmark $algorithm $i $j $k | Add-Content -Encoding ascii $q1Csv
                if ($LASTEXITCODE -ne 0) { throw "Benchmark failed: $algorithm $i $j $k" }
            }
        }
    }
}

"algorithm,I,J,K,repeats,avg_ms,gflops" | Set-Content -Encoding ascii $q3Csv
foreach ($algorithm in "ikj", "bt", "blocked", "blocked-unrolled") {
    & $binary --benchmark $algorithm 1024 1024 1024 | Add-Content -Encoding ascii $q3Csv
    if ($LASTEXITCODE -ne 0) { throw "Optimization benchmark failed: $algorithm" }
}

Write-Output "Wrote $q1Csv and $q3Csv"
