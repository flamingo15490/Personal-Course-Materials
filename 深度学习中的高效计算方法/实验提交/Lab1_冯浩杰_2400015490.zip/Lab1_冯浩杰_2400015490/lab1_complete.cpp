#include <algorithm>
#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>

using Matrix = std::vector<std::int64_t>;

struct Shape {
  int i;
  int j;
  int k;
};

using Kernel = void (*)(const Matrix&, const Matrix&, Matrix&, const Shape&);

Matrix make_matrix(int rows, int cols, int salt) {
  Matrix result(static_cast<size_t>(rows) * cols);
  for (int r = 0; r < rows; ++r) {
    for (int c = 0; c < cols; ++c) {
      result[static_cast<size_t>(r) * cols + c] =
          ((r * 17 + c * 31 + salt) % 11) - 5;
    }
  }
  return result;
}

void clear(Matrix& c) { std::fill(c.begin(), c.end(), 0); }

void gemm_ijk(const Matrix& a, const Matrix& b, Matrix& c, const Shape& s) {
  clear(c);
  for (int i = 0; i < s.i; ++i)
    for (int j = 0; j < s.j; ++j)
      for (int k = 0; k < s.k; ++k)
        c[static_cast<size_t>(i) * s.j + j] +=
            a[static_cast<size_t>(i) * s.k + k] * b[static_cast<size_t>(k) * s.j + j];
}

void gemm_ikj(const Matrix& a, const Matrix& b, Matrix& c, const Shape& s) {
  clear(c);
  for (int i = 0; i < s.i; ++i)
    for (int k = 0; k < s.k; ++k) {
      const std::int64_t av = a[static_cast<size_t>(i) * s.k + k];
      for (int j = 0; j < s.j; ++j)
        c[static_cast<size_t>(i) * s.j + j] += av * b[static_cast<size_t>(k) * s.j + j];
    }
}

void gemm_at(const Matrix& a, const Matrix& b, Matrix& c, const Shape& s) {
  Matrix at(static_cast<size_t>(s.k) * s.i);
  for (int i = 0; i < s.i; ++i)
    for (int k = 0; k < s.k; ++k)
      at[static_cast<size_t>(k) * s.i + i] = a[static_cast<size_t>(i) * s.k + k];
  clear(c);
  for (int i = 0; i < s.i; ++i)
    for (int j = 0; j < s.j; ++j)
      for (int k = 0; k < s.k; ++k)
        c[static_cast<size_t>(i) * s.j + j] +=
            at[static_cast<size_t>(k) * s.i + i] * b[static_cast<size_t>(k) * s.j + j];
}

void gemm_bt(const Matrix& a, const Matrix& b, Matrix& c, const Shape& s) {
  Matrix bt(static_cast<size_t>(s.j) * s.k);
  for (int k = 0; k < s.k; ++k)
    for (int j = 0; j < s.j; ++j)
      bt[static_cast<size_t>(j) * s.k + k] = b[static_cast<size_t>(k) * s.j + j];
  clear(c);
  for (int i = 0; i < s.i; ++i)
    for (int j = 0; j < s.j; ++j)
      for (int k = 0; k < s.k; ++k)
        c[static_cast<size_t>(i) * s.j + j] +=
            a[static_cast<size_t>(i) * s.k + k] * bt[static_cast<size_t>(j) * s.k + k];
}

void gemm_blocked(const Matrix& a, const Matrix& b, Matrix& c, const Shape& s) {
  constexpr int block = 64;
  clear(c);
  for (int ii = 0; ii < s.i; ii += block)
    for (int kk = 0; kk < s.k; kk += block)
      for (int jj = 0; jj < s.j; jj += block)
        for (int i = ii; i < std::min(ii + block, s.i); ++i)
          for (int k = kk; k < std::min(kk + block, s.k); ++k) {
            const auto av = a[static_cast<size_t>(i) * s.k + k];
            for (int j = jj; j < std::min(jj + block, s.j); ++j)
              c[static_cast<size_t>(i) * s.j + j] += av * b[static_cast<size_t>(k) * s.j + j];
          }
}

void gemm_blocked_unrolled(const Matrix& a, const Matrix& b, Matrix& c, const Shape& s) {
  constexpr int block = 64;
  clear(c);
  for (int ii = 0; ii < s.i; ii += block)
    for (int kk = 0; kk < s.k; kk += block)
      for (int jj = 0; jj < s.j; jj += block)
        for (int i = ii; i < std::min(ii + block, s.i); ++i)
          for (int k = kk; k < std::min(kk + block, s.k); ++k) {
            const auto av = a[static_cast<size_t>(i) * s.k + k];
            int j = jj;
            const int end = std::min(jj + block, s.j);
            for (; j + 3 < end; j += 4) {
              c[static_cast<size_t>(i) * s.j + j] += av * b[static_cast<size_t>(k) * s.j + j];
              c[static_cast<size_t>(i) * s.j + j + 1] += av * b[static_cast<size_t>(k) * s.j + j + 1];
              c[static_cast<size_t>(i) * s.j + j + 2] += av * b[static_cast<size_t>(k) * s.j + j + 2];
              c[static_cast<size_t>(i) * s.j + j + 3] += av * b[static_cast<size_t>(k) * s.j + j + 3];
            }
            for (; j < end; ++j)
              c[static_cast<size_t>(i) * s.j + j] += av * b[static_cast<size_t>(k) * s.j + j];
          }
}

Kernel select_kernel(const std::string& name) {
  if (name == "ijk") return gemm_ijk;
  if (name == "ikj") return gemm_ikj;
  if (name == "at") return gemm_at;
  if (name == "bt") return gemm_bt;
  if (name == "blocked") return gemm_blocked;
  if (name == "blocked-unrolled") return gemm_blocked_unrolled;
  throw std::invalid_argument("unknown algorithm: " + name);
}

void require_equal(const Matrix& actual, const Matrix& expected, const std::string& name) {
  if (actual != expected) throw std::runtime_error(name + " produced an incorrect result");
}

void test_gemm_kernels() {
  const Shape s{7, 9, 5};
  const Matrix a = make_matrix(s.i, s.k, 1);
  const Matrix b = make_matrix(s.k, s.j, 7);
  Matrix reference(static_cast<size_t>(s.i) * s.j);
  gemm_ijk(a, b, reference, s);
  for (const std::string name : {"ikj", "at", "bt", "blocked", "blocked-unrolled"}) {
    Matrix output(reference.size());
    select_kernel(name)(a, b, output, s);
    require_equal(output, reference, name);
  }
}

// Converts NCHW input into a (C * KH * KW) x (OH * OW) matrix.
Matrix im2col(const Matrix& input, int channels, int height, int width,
              int kernel, int stride, int padding) {
  const int out_h = (height + 2 * padding - kernel) / stride + 1;
  const int out_w = (width + 2 * padding - kernel) / stride + 1;
  Matrix columns(static_cast<size_t>(channels) * kernel * kernel * out_h * out_w);
  for (int c = 0; c < channels; ++c)
    for (int kh = 0; kh < kernel; ++kh)
      for (int kw = 0; kw < kernel; ++kw) {
        const int row = (c * kernel + kh) * kernel + kw;
        for (int oh = 0; oh < out_h; ++oh)
          for (int ow = 0; ow < out_w; ++ow) {
            const int ih = oh * stride + kh - padding;
            const int iw = ow * stride + kw - padding;
            const auto col = oh * out_w + ow;
            if (ih >= 0 && ih < height && iw >= 0 && iw < width)
              columns[static_cast<size_t>(row) * out_h * out_w + col] =
                  input[(static_cast<size_t>(c) * height + ih) * width + iw];
          }
      }
  return columns;
}

void test_im2col_convolution() {
  constexpr int channels = 3, height = 56, width = 56, filters = 64, kernel = 3;
  constexpr int out_h = 54, out_w = 54;
  const Matrix input = make_matrix(channels, height * width, 3);
  const Matrix weights = make_matrix(filters, channels * kernel * kernel, 9);
  const Matrix columns = im2col(input, channels, height, width, kernel, 1, 0);
  Shape gemm_shape{filters, out_h * out_w, channels * kernel * kernel};
  Matrix via_gemm(static_cast<size_t>(filters) * out_h * out_w);
  gemm_ikj(weights, columns, via_gemm, gemm_shape);
  Matrix direct(via_gemm.size());
  for (int f = 0; f < filters; ++f)
    for (int oh = 0; oh < out_h; ++oh)
      for (int ow = 0; ow < out_w; ++ow)
        for (int c = 0; c < channels; ++c)
          for (int kh = 0; kh < kernel; ++kh)
            for (int kw = 0; kw < kernel; ++kw)
              direct[static_cast<size_t>(f) * out_h * out_w + oh * out_w + ow] +=
                  weights[static_cast<size_t>(f) * channels * kernel * kernel + (c * kernel + kh) * kernel + kw] *
                  input[(static_cast<size_t>(c) * height + oh + kh) * width + ow + kw];
  require_equal(via_gemm, direct, "im2col convolution");
}

void run_self_test() {
  test_gemm_kernels();
  test_im2col_convolution();
  std::cout << "SELF_TEST_PASS: all GEMM kernels and im2col convolution are correct\n";
}

void benchmark(const std::string& algorithm, Shape s, int repeats) {
  if (s.i <= 0 || s.j <= 0 || s.k <= 0 || repeats <= 0) throw std::invalid_argument("dimensions and repeats must be positive");
  const Matrix a = make_matrix(s.i, s.k, 1);
  const Matrix b = make_matrix(s.k, s.j, 7);
  Matrix c(static_cast<size_t>(s.i) * s.j);
  const Kernel kernel = select_kernel(algorithm);
  Matrix reference(c.size());
  gemm_ijk(a, b, reference, s);
  kernel(a, b, c, s);
  require_equal(c, reference, algorithm);
  kernel(a, b, c, s);
  const auto start = std::chrono::steady_clock::now();
  for (int r = 0; r < repeats; ++r) kernel(a, b, c, s);
  const auto end = std::chrono::steady_clock::now();
  const double milliseconds = std::chrono::duration<double, std::milli>(end - start).count() / repeats;
  const double gflops = (2.0 * s.i * s.j * s.k) / (milliseconds * 1.0e6);
  std::cout << algorithm << ',' << s.i << ',' << s.j << ',' << s.k << ',' << repeats << ','
            << std::fixed << std::setprecision(4) << milliseconds << ',' << std::setprecision(3) << gflops << '\n';
}

int main(int argc, char** argv) {
  try {
    if (argc == 2 && std::string(argv[1]) == "--self-test") { run_self_test(); return 0; }
    if ((argc == 6 || argc == 7) && std::string(argv[1]) == "--benchmark") {
      const int repeats = argc == 7 ? std::atoi(argv[6]) : 32;
      benchmark(argv[2], {std::atoi(argv[3]), std::atoi(argv[4]), std::atoi(argv[5])}, repeats);
      return 0;
    }
    std::cerr << "Usage: lab1_complete --self-test | --benchmark <algorithm> I J K [repeats]\n";
    return 2;
  } catch (const std::exception& error) {
    std::cerr << "ERROR: " << error.what() << '\n';
    return 1;
  }
}
